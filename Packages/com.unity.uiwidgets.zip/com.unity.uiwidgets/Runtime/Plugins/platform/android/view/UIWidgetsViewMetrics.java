package com.unity.uiwidgets.plugin;

public class UIWidgetsViewMetrics {
    public float insets_top;
    public float insets_bottom;
    public float insets_left;
    public float insets_right;
        
    public float padding_top;
    public float padding_bottom;
    public float padding_left;
    public float padding_right;
}