using UnityEngine;

namespace Unity.UIWidgets.foundation {
    public class FoundationConstants {
        public static bool kReleaseMode = !Debug.isDebugBuild;
    }
}